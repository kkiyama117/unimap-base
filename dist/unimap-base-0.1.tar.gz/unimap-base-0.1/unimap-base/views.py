from django.shortcuts import render


def index():
    pass
