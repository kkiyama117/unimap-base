from django.apps import AppConfig


class UnimapConfig(AppConfig):
    name = 'unimap'
